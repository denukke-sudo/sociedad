const path=require('path');
const fs=require('fs');
const {bundle}=require('@remotion/bundler');
const browserExecutable=process.env.REMOTION_BROWSER_EXECUTABLE || (fs.existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined);
const {selectComposition,renderMedia,renderStill}=require('@remotion/renderer');
(async()=>{
 const serveUrl=await bundle({entryPoint:path.resolve('src/index.jsx'),outDir:path.resolve('dist')});
 const options={serveUrl,id:'ReUso',browserExecutable};
 const composition=await selectComposition(options);
 const data=JSON.parse(fs.readFileSync('composition_data.json','utf8'));
 if(process.argv.includes('--stills')){
  for(let i=0;i<data.scenes.length;i++){
   const scene=data.scenes[i];
   await renderStill({serveUrl,composition,browserExecutable,output:path.resolve('out',`scene-${String(i+1).padStart(2,'0')}.png`),frame:scene.startFrame+Math.min(90,scene.frames-30),imageFormat:'png'});
   console.log(`Still ${i+1}/${data.scenes.length}`);
  }
 }else{
  let reported=-1;
  await renderMedia({serveUrl,composition,browserExecutable,outputLocation:path.resolve('out/ReUso_Video_Narrado.mp4'),codec:'h264',crf:22,pixelFormat:'yuv420p',audioCodec:'aac',audioBitrate:'192k',concurrency:3,onProgress:({progress})=>{const p=Math.floor(progress*20)*5;if(p>reported){reported=p;console.log(`Render ${p}%`);}}});
  console.log('Video terminado');
 }
})().catch(e=>{console.error(e);process.exit(1)});
