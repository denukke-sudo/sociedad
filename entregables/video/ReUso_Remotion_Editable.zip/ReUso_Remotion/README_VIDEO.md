# ReUso — video narrado

Video explicativo del proyecto ReUso, creado con Remotion 4.0.539.

- Formato: MP4, 1920 × 1080, 30 fps, video H.264 y audio AAC.
- Duración prevista: 3 minutos y 47 segundos.
- Narración sintética en español, voz peninsular generada localmente con Piper.
- Catorce escenas: idea, funcionamiento, público, demostración, diagnóstico, ejes, leyes, cronograma, curso, herramientas, presupuesto, evaluación y propuesta empresarial.
- Las pantallas de la aplicación muestran ejemplos ficticios. Las encuestas, acuerdos y resultados del piloto siguen siendo propuestas.
- Diseño basado en DESIGN.md y en los documentos de ReUso preparados previamente.

## Archivos

- `ReUso_Video_Narrado.mp4`: video final para reproducir o presentar.
- `Guion_Video_ReUso.txt`: narración y marcas de inicio de las escenas.
- `ReUso_Remotion_Editable.zip`: proyecto fuente con imágenes y audios finales.
- `VOZ_FUENTE_Y_LICENCIA.txt`: procedencia de la voz y sus referencias.

## Editar o volver a exportar

Descomprimir el proyecto editable y abrir una terminal en esa carpeta. Requiere Node.js y npm:

```sh
npm ci
npm run preview
```

Los textos, imágenes y tiempos están en `composition_data.json`. El diseño y las animaciones están en `src/index.jsx`. Los archivos de `public/` son los recursos que utiliza el video.

```sh
npm run render
```

El MP4 aparecerá en `out/ReUso_Video_Narrado.mp4`. El render usa Chromium del sistema cuando existe en `/usr/bin/chromium`; en otro equipo Remotion puede descargar su navegador. También se puede configurar `REMOTION_BROWSER_EXECUTABLE` con la ruta de un navegador compatible.

El contenido está controlado por una plantilla y archivos JSON. Cambiar la narración requiere reemplazar el audio correspondiente y ajustar la duración de la escena, manteniendo el margen antes y después de la voz. No se incluyen los pesos del modelo de voz ni dependencias instaladas.

La elaboración utilizó IA como apoyo para guion, diseño, imágenes y voz sintética. La revisión y defensa académica del proyecto corresponden a sus integrantes.
