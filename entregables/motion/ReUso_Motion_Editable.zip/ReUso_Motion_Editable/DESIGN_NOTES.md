# ReUso — motion UI loop

## Lectura del encargo

Una pieza cuadrada de 14 segundos presenta ReUso como una interfaz continua: un único objeto se transforma, bajo la acción de un cursor, desde la publicación de un sobrante hasta la confirmación de una búsqueda.

## Inventario propio de ReUso

- Publicar sobrantes de obra reutilizables.
- Buscar materiales disponibles cerca.
- Ventanas, puertas, cerámicos y otros materiales reconocibles.
- La Plata como ubicación propuesta del piloto.
- Publicaciones, búsquedas y donaciones como categorías.
- Reserva o solicitud sin transporte ni depósito gestionado por ReUso.
- Meta piloto de 20 publicaciones, claramente rotulada como meta.
- Catálogo y detalle del material como interfaz principal.
- Disponibilidad expresada por cantidad, no por un valor ficticio.
- Confirmación de una solicitud como acción final.

## Pregunta y hallazgo

- Pregunta: ¿cómo pasa un sobrante de obra de estar guardado a encontrar una segunda vida?
- Hallazgo: el recorrido completo puede explicarse con el mismo contenedor que cambia de función, sin cortar la escena.

## Idea

En esta pieza, el sobrante reutilizable de ReUso se convierte en el mismo objeto de interfaz que publica, filtra, mide, busca y confirma su próxima utilización.

## Dirección visual

- Lienzo: gris cálido `#F1EFEA`.
- Tinta: `#0B0C0B`.
- Superficie: `#FFFFFF`.
- Único acento: verde circular `#168A5B`.
- Tipografía: Geist Variable.
- Sin degradados, brillos, partículas ni sombras de elementos en reposo.
- Un único trazo de iconos, con terminaciones redondas.
- Resortes cerrados y deterministas, con sobrepaso prácticamente imperceptible.
- El cursor forma parte de la narración visual y vuelve exactamente a su posición inicial.

## Estados

1. Botón «Publicar sobrante».
2. Loader.
3. Check.
4. Isla dinámica.
5. Vista previa del material.
6. Barra de progreso.
7. Control de disponibilidad.
8. Toggle «Solo cerca».
9. Pestañas.
10. Gráfico de la meta piloto.
11. Buscador.
12. Toast.
13. Regreso exacto al botón inicial.

