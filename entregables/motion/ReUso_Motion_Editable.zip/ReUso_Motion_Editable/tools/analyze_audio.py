#!/usr/bin/env python3
"""Measure the synthesized song's beat transients with NumPy."""

from __future__ import annotations

import json
import wave
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "assets" / "ReUso_Original_120BPM.wav"
OUTPUT = ROOT / "assets" / "beat_grid.json"
BPM_NOMINAL = 120.0
BEAT_SECONDS = 60.0 / BPM_NOMINAL
BEAT_COUNT = 28


def read_wav(path: Path) -> tuple[int, np.ndarray]:
    with wave.open(str(path), "rb") as wav:
        if wav.getsampwidth() != 2:
            raise ValueError("Expected 16-bit PCM")
        sr = wav.getframerate()
        channels = wav.getnchannels()
        data = np.frombuffer(wav.readframes(wav.getnframes()), dtype="<i2")
    audio = data.astype(np.float64).reshape(-1, channels) / 32768.0
    return sr, audio


def main() -> None:
    sr, stereo = read_wav(SOURCE)
    mono = stereo.mean(axis=1)

    # A differentiated, short-time energy envelope favours attacks over pads.
    high = np.diff(mono, prepend=mono[0])
    window = max(1, round(sr * 0.006))
    energy = np.convolve(high * high, np.ones(window) / window, mode="same")
    envelope = np.sqrt(np.maximum(energy, 0.0))

    measured: list[float] = []
    strengths: list[float] = []
    search_before = 0.018
    search_after = 0.055
    for beat in range(BEAT_COUNT):
        expected = beat * BEAT_SECONDS
        lo = max(0, int(round((expected - search_before) * sr)))
        hi = min(len(envelope), int(round((expected + search_after) * sr)))
        local = envelope[lo:hi]
        if not len(local):
            raise RuntimeError(f"No search window for beat {beat + 1}")
        peak = lo + int(np.argmax(local))
        measured.append(peak / sr)
        strengths.append(float(envelope[peak]))

    intervals = np.diff(measured)
    tempo = 60.0 / float(np.median(intervals))
    payload = {
        "source": SOURCE.name,
        "sample_rate": sr,
        "duration_seconds": len(mono) / sr,
        "nominal_bpm": BPM_NOMINAL,
        "measured_bpm": tempo,
        "time_signature": "4/4",
        "bars": 7,
        "beat_count": BEAT_COUNT,
        "downbeat_seconds": measured[0],
        "beats": [
            {
                "number": i + 1,
                "bar": i // 4 + 1,
                "beat_in_bar": i % 4 + 1,
                "expected_seconds": i * BEAT_SECONDS,
                "measured_peak_seconds": measured[i],
                "onset_strength": strengths[i],
            }
            for i in range(BEAT_COUNT)
        ],
    }
    OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    max_error = max(abs(item["expected_seconds"] - item["measured_peak_seconds"]) for item in payload["beats"])
    print(f"wrote {OUTPUT}")
    print(f"measured tempo {tempo:.4f} BPM | maximum beat error {max_error * 1000:.2f} ms")


if __name__ == "__main__":
    main()

