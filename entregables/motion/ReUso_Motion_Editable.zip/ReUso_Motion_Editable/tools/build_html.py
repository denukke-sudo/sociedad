#!/usr/bin/env python3
"""Build the self-contained motion HTML by embedding the font, beat grid and audio."""

from __future__ import annotations

import base64
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = ROOT / "src" / "template.html"
OUTPUT = ROOT / "ReUso_Motion_Interactivo.html"
FONT = ROOT / "node_modules" / "@fontsource-variable" / "geist" / "files" / "geist-latin-wght-normal.woff2"
AUDIO = ROOT / "assets" / "ReUso_Audio_Final.wav"
GRID = ROOT / "assets" / "beat_grid.json"


def main() -> None:
    source = TEMPLATE.read_text(encoding="utf-8")
    grid = json.loads(GRID.read_text(encoding="utf-8"))
    beat_times = [round(item["measured_peak_seconds"], 7) for item in grid["beats"]]
    replacements = {
        "__GEIST_FONT_DATA__": base64.b64encode(FONT.read_bytes()).decode("ascii"),
        "__BEAT_TIMES__": json.dumps(beat_times, separators=(",", ":")),
        "__AUDIO_DATA__": base64.b64encode(AUDIO.read_bytes()).decode("ascii"),
    }
    for marker, value in replacements.items():
        if marker not in source:
            raise RuntimeError(f"Missing template marker: {marker}")
        source = source.replace(marker, value)
    OUTPUT.write_text(source, encoding="utf-8")
    print(f"wrote {OUTPUT} ({OUTPUT.stat().st_size} bytes)")


if __name__ == "__main__":
    main()

