#!/usr/bin/env python3
"""Validate the final MP4 and the exact HTML loop boundary."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import numpy as np
from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
VIDEO = ROOT / "out" / "ReUso_Motion_120BPM.mp4"
REPORT = ROOT / "out" / "validacion_motion.json"


def probe() -> dict:
    raw = subprocess.check_output(
        [
            "ffprobe", "-v", "error", "-count_frames",
            "-show_entries",
            "stream=index,codec_type,codec_name,width,height,r_frame_rate,nb_read_frames,sample_rate,channels,duration:format=duration,size",
            "-of", "json", str(VIDEO),
        ],
        text=True,
    )
    return json.loads(raw)


def main() -> None:
    info = probe()
    streams = {item["codec_type"]: item for item in info["streams"]}
    video = streams["video"]
    audio = streams["audio"]
    duration = float(info["format"]["duration"])
    audio_duration = float(audio["duration"])
    frames = int(video["nb_read_frames"])
    assert video["codec_name"] == "h264"
    assert (int(video["width"]), int(video["height"])) == (1440, 1440)
    assert video["r_frame_rate"] == "60/1"
    assert frames == 840
    assert abs(duration - 14.0) <= 0.03
    assert audio["codec_name"] == "aac"
    assert int(audio["sample_rate"]) == 48000
    assert int(audio["channels"]) == 2
    assert abs(audio_duration - 14.0) <= 0.03

    subprocess.run(["ffmpeg", "-v", "error", "-i", str(VIDEO), "-f", "null", "-"], check=True)

    first_path = ROOT / "out" / "loop-first.png"
    last_path = ROOT / "out" / "loop-last.png"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(VIDEO), "-vf", "select=eq(n\\,0)", "-frames:v", "1", str(first_path)], check=True)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-sseof", "-0.02", "-i", str(VIDEO), "-frames:v", "1", str(last_path)], check=True)
    first = np.asarray(Image.open(first_path).convert("RGB"), dtype=np.int16)
    last = np.asarray(Image.open(last_path).convert("RGB"), dtype=np.int16)
    visual_delta = np.abs(first - last)
    mean_delta = float(visual_delta.mean())
    assert mean_delta < 2.0, f"Loop boundary mean channel delta is too high: {mean_delta:.3f}"

    report = {
        "file": VIDEO.name,
        "width": 1440,
        "height": 1440,
        "fps": 60,
        "frames": frames,
        "duration_seconds": duration,
        "video_codec": video["codec_name"],
        "audio_codec": audio["codec_name"],
        "sample_rate": int(audio["sample_rate"]),
        "channels": int(audio["channels"]),
        "audio_duration_seconds": audio_duration,
        "size_bytes": int(info["format"]["size"]),
        "full_decode": "passed",
        "first_last_mean_channel_delta": mean_delta,
        "first_last_max_channel_delta": int(visual_delta.max()),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

