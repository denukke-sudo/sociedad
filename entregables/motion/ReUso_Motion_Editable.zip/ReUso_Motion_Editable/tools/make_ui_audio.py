#!/usr/bin/env python3
"""Create UI cues, align each cue by its measured peak, and mix the final loop."""

from __future__ import annotations

import json
import math
import wave
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
MUSIC = ASSETS / "ReUso_Original_120BPM.wav"
GRID = ASSETS / "beat_grid.json"
UI_OUT = ASSETS / "ReUso_UI_Sonidos.wav"
FINAL_OUT = ASSETS / "ReUso_Audio_Final.wav"
MANIFEST = ASSETS / "ui_sound_manifest.json"
RNG = np.random.default_rng(27102026)


def read_wav(path: Path) -> tuple[int, np.ndarray]:
    with wave.open(str(path), "rb") as wav:
        if wav.getsampwidth() != 2:
            raise ValueError("Expected 16-bit PCM")
        sr = wav.getframerate()
        channels = wav.getnchannels()
        raw = np.frombuffer(wav.readframes(wav.getnframes()), dtype="<i2")
    return sr, raw.astype(np.float64).reshape(-1, channels) / 32768.0


def write_wav(path: Path, sr: int, audio: np.ndarray) -> None:
    pcm = np.clip(np.round(audio * 32767.0), -32768, 32767).astype("<i2")
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(audio.shape[1])
        wav.setsampwidth(2)
        wav.setframerate(sr)
        wav.writeframes(pcm.tobytes())


def stereo(mono: np.ndarray, pan: float = 0.0) -> np.ndarray:
    angle = (pan + 1.0) * math.pi / 4.0
    return np.column_stack((mono * math.cos(angle), mono * math.sin(angle)))


def click(sr: int, variant: float = 1.0) -> np.ndarray:
    length = int(0.055 * sr)
    tt = np.arange(length) / sr
    attack = np.minimum(1.0, tt / 0.0015)
    env = attack * np.exp(-tt / 0.014)
    tone = np.sin(2 * np.pi * (1180 * variant) * tt)
    noise = RNG.standard_normal(length)
    noise = np.concatenate(([0.0], np.diff(noise)))
    return (0.62 * tone + 0.06 * noise) * env


def tick(sr: int) -> np.ndarray:
    length = int(0.035 * sr)
    tt = np.arange(length) / sr
    env = np.minimum(1.0, tt / 0.001) * np.exp(-tt / 0.009)
    return np.sin(2 * np.pi * 1520 * tt) * env


def chime(sr: int) -> np.ndarray:
    length = int(0.28 * sr)
    tt = np.arange(length) / sr
    attack = np.minimum(1.0, tt / 0.004)
    env = attack * np.exp(-tt / 0.11)
    a = np.sin(2 * np.pi * 659.255 * tt)
    b = np.sin(2 * np.pi * 987.767 * np.maximum(0.0, tt - 0.045))
    b *= (tt >= 0.045)
    return (0.48 * a + 0.34 * b) * env


def place_by_peak(bus: np.ndarray, sound: np.ndarray, target: float, sr: int, pan: float) -> dict:
    peak_index = int(np.argmax(np.abs(sound)))
    start = int(round(target * sr)) - peak_index
    shaped = stereo(sound, pan)
    source_lo = max(0, -start)
    dest_lo = max(0, start)
    count = min(len(shaped) - source_lo, len(bus) - dest_lo)
    if count > 0:
        bus[dest_lo : dest_lo + count] += shaped[source_lo : source_lo + count]
    return {
        "scheduled_peak_seconds": target,
        "source_peak_seconds": peak_index / sr,
        "placed_start_seconds": start / sr,
    }


def main() -> None:
    sr, music = read_wav(MUSIC)
    grid = json.loads(GRID.read_text(encoding="utf-8"))
    beat_peaks = [item["measured_peak_seconds"] for item in grid["beats"]]
    ui = np.zeros_like(music)
    entries: list[dict] = []

    events = [
        ("publicar_click", click(sr, 1.00), beat_peaks[2], -0.20, 0.20),
        ("check", chime(sr), beat_peaks[7], 0.12, 0.20),
        ("play_click", click(sr, 0.94), beat_peaks[11], 0.18, 0.16),
        ("scrub_grab", click(sr, 1.08), beat_peaks[12], -0.10, 0.13),
        ("scrub_release", tick(sr), beat_peaks[13], 0.14, 0.12),
        ("slider_limit", tick(sr), beat_peaks[15], -0.14, 0.12),
        ("toggle_click", click(sr, 1.03), beat_peaks[18], 0.14, 0.17),
        ("tab_click", click(sr, 0.97), beat_peaks[21], -0.14, 0.17),
        ("tooltip", tick(sr), beat_peaks[24], 0.12, 0.10),
        ("enter", click(sr, 0.90), beat_peaks[26], 0.0, 0.18),
    ]

    # Seven quiet key taps between the command-palette click and Enter.
    typed = "ventana"
    for i, char in enumerate(typed):
        t = 12.58 + i * 0.052
        events.append((f"tecla_{char}_{i + 1}", click(sr, 1.18 + 0.02 * (i % 3)), t, -0.18 + 0.06 * i, 0.055))

    for name, sound, target, pan, gain in events:
        placement = place_by_peak(ui, sound * gain, target, sr, pan)
        entries.append({"name": name, **placement})

    ui_peak = float(np.max(np.abs(ui)))
    if ui_peak > 0.72:
        ui *= 0.72 / ui_peak

    # Keep the music's punch, add the cues, then use soft saturation and a -1.2 dBFS ceiling.
    mixed = np.tanh(music * 1.02 + ui * 0.92)
    mixed *= (10 ** (-1.2 / 20.0)) / float(np.max(np.abs(mixed)))
    write_wav(UI_OUT, sr, ui)
    write_wav(FINAL_OUT, sr, mixed)

    MANIFEST.write_text(
        json.dumps(
            {
                "sample_rate": sr,
                "placement_rule": "Each source is offset so its measured maximum sample lands at the scheduled time.",
                "events": entries,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    print(f"wrote {UI_OUT}")
    print(f"wrote {FINAL_OUT}")
    print(f"wrote {MANIFEST}")


if __name__ == "__main__":
    main()

