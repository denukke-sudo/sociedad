#!/usr/bin/env python3
"""Generate ReUso's original 120 BPM loop using only synthesized waveforms."""

from __future__ import annotations

import math
import wave
from pathlib import Path

import numpy as np


SR = 48_000
BPM = 120
BEAT = 60 / BPM
BARS = 7
BEATS_PER_BAR = 4
DURATION = BARS * BEATS_PER_BAR * BEAT
N = int(SR * DURATION)
OUT = Path(__file__).resolve().parents[1] / "assets" / "ReUso_Original_120BPM.wav"
RNG = np.random.default_rng(20261031)


def hz(midi: float) -> float:
    return 440.0 * 2.0 ** ((midi - 69.0) / 12.0)


def equal_power_pan(mono: np.ndarray, position: float) -> np.ndarray:
    angle = (position + 1.0) * math.pi / 4.0
    return np.column_stack((mono * math.cos(angle), mono * math.sin(angle)))


def place(bus: np.ndarray, sound: np.ndarray, start_seconds: float, pan: float = 0.0) -> None:
    """Circular placement lets release tails cross the loop seam without a click."""
    stereo = equal_power_pan(sound, pan)
    start = int(round(start_seconds * SR)) % N
    end = start + len(stereo)
    if end <= N:
        bus[start:end] += stereo
    else:
        first = N - start
        bus[start:] += stereo[:first]
        bus[: end - N] += stereo[first:]


def attack_decay(length: int, attack: float, decay: float) -> np.ndarray:
    tt = np.arange(length) / SR
    env = np.exp(-tt / decay)
    attack_n = max(1, int(attack * SR))
    env[:attack_n] *= np.linspace(0.0, 1.0, attack_n, endpoint=False)
    return env


def kick(accent: float) -> np.ndarray:
    length = int(0.34 * SR)
    tt = np.arange(length) / SR
    freq = 46.0 + 62.0 * np.exp(-tt / 0.035)
    phase = 2.0 * np.pi * np.cumsum(freq) / SR
    body = np.sin(phase) * attack_decay(length, 0.002, 0.105)
    click = RNG.standard_normal(length)
    click = np.concatenate(([0.0], np.diff(click))) * np.exp(-tt / 0.008)
    return accent * (0.92 * body + 0.035 * click)


def snare() -> np.ndarray:
    length = int(0.24 * SR)
    tt = np.arange(length) / SR
    noise = RNG.standard_normal(length)
    bright = np.concatenate(([0.0], np.diff(noise)))
    env = attack_decay(length, 0.004, 0.075)
    tone = np.sin(2.0 * np.pi * 178.0 * tt) * np.exp(-tt / 0.095)
    return 0.34 * bright * env + 0.20 * tone * env


def hat(open_hat: bool = False) -> np.ndarray:
    length = int((0.18 if open_hat else 0.075) * SR)
    tt = np.arange(length) / SR
    noise = RNG.standard_normal(length)
    bright = np.concatenate(([0.0], np.diff(noise)))
    decay = 0.07 if open_hat else 0.021
    return 0.11 * bright * attack_decay(length, 0.001, decay)


def bass(note: int, length_s: float = 0.43) -> np.ndarray:
    length = int(length_s * SR)
    tt = np.arange(length) / SR
    f = hz(note)
    phase = 2.0 * np.pi * f * tt
    tone = np.sin(phase) + 0.22 * np.sin(2 * phase) + 0.07 * np.sin(3 * phase)
    return 0.27 * tone * attack_decay(length, 0.012, 0.23)


def pluck(note: int, decay: float = 0.17) -> np.ndarray:
    length = int(0.38 * SR)
    tt = np.arange(length) / SR
    f = hz(note)
    phase = 2.0 * np.pi * f * tt
    tone = (
        np.sin(phase)
        + 0.45 * np.sin(2 * phase + 0.13)
        + 0.16 * np.sin(3 * phase + 0.31)
        + 0.07 * np.sin(5 * phase)
    )
    return 0.15 * tone * attack_decay(length, 0.003, decay)


def pad(note: int, length_s: float = 2.35) -> np.ndarray:
    length = int(length_s * SR)
    tt = np.arange(length) / SR
    f = hz(note)
    phase = 2.0 * np.pi * f * tt
    tone = np.sin(phase) + 0.24 * np.sin(2 * phase) + 0.08 * np.sin(3 * phase)
    attack = np.minimum(1.0, tt / 0.11)
    release = np.minimum(1.0, np.maximum(0.0, (length_s - tt) / 0.42))
    return 0.055 * tone * attack * release


def main() -> None:
    mix = np.zeros((N, 2), dtype=np.float64)
    roots = [48, 55, 57, 53, 48, 55, 55]  # C, G, Am, F, C, G, G -> C loop
    thirds = [4, 4, 3, 4, 4, 4, 4]
    arp_pattern = [0, 1, 2, 1, 0, 2, 1, 2]

    # Pads establish the seven-bar harmonic arc; their tails wrap seamlessly.
    for bar, root in enumerate(roots):
        chord = [root, root + thirds[bar], root + 7]
        for voice, note in enumerate(chord):
            place(mix, pad(note + 12), bar * 4 * BEAT - 0.035, (-0.52, 0.0, 0.52)[voice])

    # Beat grid and direct, crisp percussion.
    for beat in range(BARS * BEATS_PER_BAR):
        in_bar = beat % 4
        place(mix, kick(1.0 if in_bar == 0 else 0.78), beat * BEAT)
        if in_bar in (1, 3):
            place(mix, snare(), beat * BEAT, 0.04 if in_bar == 1 else -0.04)
        place(mix, hat(False), beat * BEAT, -0.22)
        place(mix, hat(in_bar == 3), beat * BEAT + BEAT / 2, 0.30)

    # Bass answers on beats 1 and 3 of each bar.
    for bar, root in enumerate(roots):
        bar_start = bar * 4 * BEAT
        place(mix, bass(root), bar_start, -0.08)
        fifth_or_third = root + (7 if bar % 2 == 0 else thirds[bar])
        place(mix, bass(fifth_or_third), bar_start + 2 * BEAT, 0.07)

    # An eighth-note pluck keeps every half-beat active while remaining understated.
    for step in range(BARS * BEATS_PER_BAR * 2):
        bar = min(BARS - 1, step // 8)
        root = roots[bar]
        chord = [root + 12, root + thirds[bar] + 12, root + 19]
        note = chord[arp_pattern[step % 8]]
        pan = -0.38 if step % 2 == 0 else 0.38
        place(mix, pluck(note), step * BEAT / 2 + 0.018, pan)

    # Gentle bus saturation and peak normalization; no samples or external material.
    mix = np.tanh(mix * 1.35)
    peak = float(np.max(np.abs(mix)))
    mix *= 10 ** (-1.0 / 20.0) / peak
    pcm = np.clip(np.round(mix * 32767.0), -32768, 32767).astype("<i2")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(OUT), "wb") as wav:
        wav.setnchannels(2)
        wav.setsampwidth(2)
        wav.setframerate(SR)
        wav.writeframes(pcm.tobytes())

    print(f"wrote {OUT} | {DURATION:.3f}s | {BPM} BPM | {SR} Hz | peak {peak:.4f}")


if __name__ == "__main__":
    main()
