#!/usr/bin/env python3
"""Render beat proofs or the full 60 fps loop from the self-contained HTML."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import math
import shutil
import subprocess
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from playwright.async_api import async_playwright


ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / "ReUso_Motion_Interactivo.html"
PREVIEW = ROOT / "preview"
FRAMES = ROOT / "frames_raw"
OUT = ROOT / "out"
CHROMIUM = "/usr/bin/chromium"
FPS = 60
SUBFRAMES = 4
DURATION = 14
OUTPUT_FRAMES = FPS * DURATION


async def open_page(browser):
    page = await browser.new_page(viewport={"width": 1440, "height": 1440}, device_scale_factor=1)
    await page.set_content(HTML.read_text(encoding="utf-8"), wait_until="load")
    await page.wait_for_function("window.renderReady === true")
    return page


async def capture(page, t: float, path: Path) -> None:
    await page.evaluate("(time) => window.seek(time)", t)
    await page.locator("#stage").screenshot(path=str(path), animations="disabled")


def make_contact_sheet(paths: list[Path], output: Path) -> None:
    thumb = 360
    sheet = Image.new("RGB", (thumb * 4, thumb * 7), "#f1efea")
    draw = ImageDraw.Draw(sheet)
    for index, path in enumerate(paths):
        with Image.open(path) as im:
            image = im.convert("RGB").resize((thumb, thumb), Image.Resampling.LANCZOS)
        x = (index % 4) * thumb
        y = (index // 4) * thumb
        sheet.paste(image, (x, y))
        draw.rectangle((x + 10, y + 10, x + 78, y + 42), fill="#0b0c0b")
        draw.text((x + 21, y + 17), f"{index + 1}", fill="white")
    sheet.save(output)


async def render_beats() -> None:
    PREVIEW.mkdir(parents=True, exist_ok=True)
    grid = json.loads((ROOT / "assets" / "beat_grid.json").read_text(encoding="utf-8"))
    beat_times = [float(beat["measured_peak_seconds"]) for beat in grid["beats"]]
    if len(beat_times) != 28:
        raise RuntimeError(f"Expected 28 measured beats, found {len(beat_times)}")
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(executable_path=CHROMIUM, headless=True, args=["--disable-gpu-sandbox"])
        page = await open_page(browser)
        paths = []
        for beat, beat_time in enumerate(beat_times):
            path = PREVIEW / f"beat-{beat:02d}.png"
            await capture(page, beat_time, path)
            paths.append(path)
        start_path = PREVIEW / "beat-loop-0s.png"
        await capture(page, 0.0, start_path)
        preloop_path = PREVIEW / "beat-loop-last-subframe.png"
        await capture(page, DURATION - 0.5 / (FPS * SUBFRAMES), preloop_path)
        loop_path = PREVIEW / "beat-loop-14s.png"
        await capture(page, 14.0, loop_path)
        await browser.close()

    make_contact_sheet(paths, PREVIEW / "beat-contact-sheet.png")
    first = np.asarray(Image.open(start_path).convert("RGB"), dtype=np.int16)
    loop = np.asarray(Image.open(loop_path).convert("RGB"), dtype=np.int16)
    diff = np.abs(first - loop)
    if int(diff.max()) != 0:
        raise RuntimeError(f"seek(0) and seek(14) differ: max channel delta {int(diff.max())}")
    preloop = np.asarray(Image.open(preloop_path).convert("RGB"), dtype=np.int16)
    preloop_diff = np.abs(first - preloop)
    if int(preloop_diff.max()) != 0:
        raise RuntimeError(
            "last rendered subframe and first frame differ: "
            f"max channel delta {int(preloop_diff.max())}"
        )
    print(f"beat proofs: {len(paths)}")
    print("loop proof: first, last subframe, and seek(14) are pixel-identical")
    print(f"contact sheet: {PREVIEW / 'beat-contact-sheet.png'}")


async def render_worker(browser, worker: int, start: int, stop: int) -> None:
    page = await open_page(browser)
    for raw_index in range(start, stop):
        output_frame = raw_index // SUBFRAMES
        subframe = raw_index % SUBFRAMES
        t = (output_frame + (subframe + 0.5) / SUBFRAMES) / FPS
        await capture(page, t, FRAMES / f"sub-{raw_index:06d}.png")
        if raw_index % 120 == 0:
            print(f"worker {worker}: {raw_index}/{OUTPUT_FRAMES * SUBFRAMES}", flush=True)
    await page.close()


def run_ffmpeg() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    silent = OUT / "ReUso_Motion_Sin_Audio.mp4"
    final = OUT / "ReUso_Motion_120BPM.mp4"
    subprocess.run(
        [
            "ffmpeg", "-y", "-framerate", "240", "-i", str(FRAMES / "sub-%06d.png"),
            "-vf", "tmix=frames=4:weights='1 1 1 1',select='eq(mod(n,4),3)',setpts=N/(60*TB),format=yuv420p",
            "-an", "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-r", "60",
            "-movflags", "+faststart", str(silent),
        ],
        check=True,
    )
    subprocess.run(
        [
            "ffmpeg", "-y", "-i", str(silent), "-i", str(ROOT / "assets" / "ReUso_Audio_Final.wav"),
            "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
            "-t", "14", "-movflags", "+faststart", str(final),
        ],
        check=True,
    )
    print(f"video: {final}")


async def render_full(workers: int) -> None:
    if FRAMES.exists():
        shutil.rmtree(FRAMES)
    FRAMES.mkdir(parents=True)
    total = OUTPUT_FRAMES * SUBFRAMES
    chunk = math.ceil(total / workers)
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(executable_path=CHROMIUM, headless=True, args=["--disable-gpu-sandbox"])
        tasks = []
        for worker in range(workers):
            start = worker * chunk
            stop = min(total, start + chunk)
            if start < stop:
                tasks.append(render_worker(browser, worker + 1, start, stop))
        await asyncio.gather(*tasks)
        await browser.close()
    count = len(list(FRAMES.glob("sub-*.png")))
    if count != total:
        raise RuntimeError(f"Expected {total} raw frames, found {count}")
    run_ffmpeg()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--beats", action="store_true")
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--workers", type=int, default=3)
    args = parser.parse_args()
    if args.beats == args.full:
        parser.error("Choose exactly one of --beats or --full")
    if args.beats:
        asyncio.run(render_beats())
    else:
        asyncio.run(render_full(max(1, min(3, args.workers))))


if __name__ == "__main__":
    main()

