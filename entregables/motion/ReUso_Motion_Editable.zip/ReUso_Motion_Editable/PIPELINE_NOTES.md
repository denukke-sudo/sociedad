# Render pipeline for the 14-second UI loop

## Available runtime

- Node `v24.19.0`, npm `11.9.0`.
- Chromium `/usr/bin/chromium`, version `154.0.8037.57`.
- Playwright is already available in both runtimes:
  - Python: `/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages/playwright`
  - Node: `/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright`
- FFmpeg/FFprobe `7.1.5`; `tmix`, `tblend` and `framestep` are present.
- 5 CPUs, 33 GiB RAM and about 29 GiB free under `/workspace`.

No package installation is required. Python Playwright is the least fragile option because it resolves without setting `NODE_PATH`.

## Deterministic HTML contract

The single HTML should expose:

- `window.seek(t)` where `t` is seconds in `[0, 14]`;
- `window.renderReady`, a promise resolved after `document.fonts.ready` and all decoded assets;
- a fixed `1440 × 1440` stage at device scale factor 1;
- no animation timers, CSS transitions or state read from a prior frame.

Every frame is rendered from absolute time. `seek(t)` should normalise with `t = ((t % 14) + 14) % 14`, compute all geometry and text for that instant, and draw it. The last half beat should already be at the exact initial button/cursor pose with zero velocity so frame 839 and frame 0 join cleanly.

## Beat-grid proof before the full render

At 120 BPM, one beat is `0.5 s`. Capture 28 proof frames at `t = 0.0, 0.5, …, 13.5`, plus one loop-check frame at `14.0`. A Playwright proof script should:

1. launch `/usr/bin/chromium` headless at viewport `1440 × 1440`, DPR 1;
2. open the HTML through a small local HTTP server or as a `file://` URL;
3. await `window.renderReady`;
4. call `seek(t)` and capture the stage for every beat;
5. make a 4 × 7 contact sheet with FFmpeg or Pillow;
6. compare hashes/pixels of `t=0` and `t=14`.

Review the contact sheet for cramped labels, off-grid actions and the one-accent rule before starting the expensive pass.

## Four subframes per output frame

The final video is 60 fps for 14 seconds: 840 output frames. Capture 4 temporal samples per output frame, 3,360 PNGs total, at:

```text
t = (frame + (subframe + 0.5) / 4) / 60
frame = 0…839
subframe = 0…3
```

That is an effective 240 fps shutter centred inside each 60 fps frame. Name the files `sub-000000.png` through `sub-003359.png`. With flat UI colours, expected disk use is roughly 0.5–2 GiB; there is ample workspace headroom.

Use one Chromium process and one page first. If capture time becomes excessive, use up to three pages in the same browser, each with a disjoint range of output frames. Each page must await its own fonts and assets, and filenames must be indexed by absolute subframe so parallel completion order cannot change the result.

## FFmpeg motion blur and cadence

Average each group of four samples with `tmix`, select the fourth result in every group, and retime to 60 fps:

```bash
ffmpeg -framerate 240 -i frames/sub-%06d.png \
  -vf "tmix=frames=4:weights='1 1 1 1',select='eq(mod(n,4),3)',setpts=N/(60*TB),format=yuv420p" \
  -an -c:v libx264 -preset slow -crf 18 -r 60 -movflags +faststart video-silent.mp4
```

Selecting frames 3, 7, 11, … ensures the first output already contains four real samples; it avoids the partial history that `tmix` produces at input frames 0–2. The expected output count is exactly 840.

## Audio

Analyse the selected song with NumPy before rendering:

- decode to mono float PCM with FFmpeg;
- calculate a short-time energy/onset envelope;
- estimate a period near 0.5 seconds and locate the strongest downbeat;
- cut exactly seven 4/4 bars from that downbeat;
- record measured beat times in JSON.

UI clicks should be separate WAV files with their peak sample measured. Delay each clip by `scheduled_time - peak_time`, then mix it over the song. For a seamless 14-second loop, use a naturally repeating seven-bar phrase or crossfade the music tail into its head before the final mix. Keep click peaks below the music transient ceiling and the master below `-1 dBTP`.

Mux without altering the verified video cadence:

```bash
ffmpeg -i video-silent.mp4 -i audio-final.wav \
  -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k \
  -t 14 -movflags +faststart ReUso_Motion_120BPM.mp4
```

## Validation

- `ffprobe`: 1440 × 1440, H.264, 60 fps, 840 frames, 14.000 seconds, AAC audio.
- Full decode: `ffmpeg -v error -i ReUso_Motion_120BPM.mp4 -f null -`.
- Confirm the HTML has no `transition`, `animation`, timers or `will-change`.
- Confirm frame 0 and the explicit `seek(14)` proof are pixel-identical.
- Inspect at least the 28 beat frames and representative in-between frames after motion blur.

## Main risks

- PNG capture is the slowest step. Flat canvas graphics keep files small; parallelise only if a single page is too slow.
- A web font loaded from the network can change metrics or fail during render. Embed the Geist font as a data URL in the HTML and await `document.fonts.ready`.
- Canvas must be drawn at native 1440 resolution. Scaling a lower-resolution canvas with CSS will soften type.
- If the last beat is still moving, a mathematically periodic state can still show a motion-blur discontinuity. Settle to the initial pose before the last four subframes.
